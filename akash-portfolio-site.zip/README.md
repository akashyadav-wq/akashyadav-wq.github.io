# Akash Yadav – Program Manager Portfolio

Live site: https://akashyadav-wq.github.io

Program Manager with 5+ years in EdTech: GTM, P&L and cross-functional execution.
